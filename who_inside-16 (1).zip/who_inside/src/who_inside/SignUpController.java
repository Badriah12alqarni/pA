/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package who_inside;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 * FXML Controller class
 *
 * @author rahafibrahim
 */
public class SignUpController implements Initializable {

    @FXML
    private TextField tfEmail;
    @FXML
    private TextField tfPassword;
    @FXML
    private TextField tfAge;
    @FXML
    private TextField tfUserName;
    @FXML
    private Button btNextPage;
    @FXML
    private Button btnSignIn;
    @FXML
    private Label lbMsg;
    @FXML
    private Button btNewUser;
    User DB=new User();
    boolean flag=false;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void btNextPage(ActionEvent event) throws IOException {
        if(flag==true){
        Parent root = FXMLLoader.load(getClass().getResource("signIn.fxml"));
        Scene scene = new Scene(root);
        Stage stage=(Stage) ((Node)event.getSource()).getScene().getWindow();
        stage.setTitle("Sign in");
        stage.setScene(scene);
        stage.show();}
        else
            lbMsg.setText("الرجاء التسجيل أولا !!");
    }
    @FXML
    private void setSignIn(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("signIn.fxml"));
        Scene scene = new Scene(root);
        Stage stage=(Stage) ((Node)event.getSource()).getScene().getWindow();
        stage.setTitle("Sign in");
        stage.setScene(scene);
        stage.show();
    }
    

    @FXML
    private void btNewUser(ActionEvent event) {
       
         String username,email,password,age;
        username = tfUserName.getText();
        email = tfEmail.getText();
        password = tfPassword.getText();
        age=tfAge.getText();
        if(!username.isEmpty()){
           usernameChecker(username);
             if(usernameChecker(username)==true){
                 Session se = HibernateUtil.getSessionFactory().openSession();
                 List<User> lList = null;
                 String queryStr = "from User";
                 Query query = se.createQuery(queryStr);
                 lList = query.list();
                 se.close();
                 boolean find = false;
                 for (User l : lList) {
                     if (l.getUsername().equals(tfUserName.getText())) {
                         find = true;
                         break;
                     }

                 }
                 if (find) {
                    lbMsg.setText("اسم المستخدم موجود مسبقاالرجاء اختيار اسم آخر"); 

                 }
                 else{
                 if(!email.isEmpty()){
                     emailChecker(email);
                     if(emailChecker(email)==true){
                         if(!password.isEmpty()){
                             passwordChecker(password);
                             if(passwordChecker(password)==true){
                                 if(!age.isEmpty()){
                                     ageChecker(age);
                                     if(ageChecker(age)==true){
                                          lbMsg.setText(" ");
                                         DB.setUsername(username);
                                         DB.setEmail(email);
                                         DB.setPassword(password);
                                         DB.setAge(age);
                                         Session session = HibernateUtil.getSessionFactory().openSession();

                                         Transaction tx = session.beginTransaction();
                                         session.save(DB);
                                         tx.commit();
                                         session.close();
                                         
                                         lbMsg.setText("تم التسجيل بنجاح");
                                         flag=true;
                                     }
                                     else{
                                         lbMsg.setText("فضلا ادخل العمر بشكل صحيح");
                                     }
                                 }
                                 else{
                                     lbMsg.setText("فضلا قم بادخال العمر");
                                 }
                                 
                             }
                             else{
                                  lbMsg.setText("فضلا ادخل كلمة المرور بشكل صحيح \n كلمة المرور يجب أن تحتوي على حروف كبيرة وصغيرة وأرقام ورموز ");
                             }
                         }
                         else{
                             lbMsg.setText("فضلا قم بادخال كلمة المرور");
                         }
                     }
                     else{
                         lbMsg.setText("فضلا ادخل البريد الالكتروني بشكل صحيح");
                     }
                             
                     
                 }
                 else{
                      lbMsg.setText("فضلا قم بادخال البريد الالكتروني");
                 }
                     
             
               
             }}
               else {
            lbMsg.setText("اسم المستخدم يجب أن لا يقل عن 8 أحرف ولا يزيد عن 30 حرف ");
            }
             }
            
         
        else
        {
           lbMsg.setText("فضلا قم بادخال اسم مستخدم");
        }
        
}
    public boolean usernameChecker(String username){
        
         
         if(username.length() >= 8 & username.length() <= 30 ){
               username.replace(" ", "");
              
                        
                  
                  return true;
               
         
         }
         else
             return false; 
    }
     public boolean emailChecker(String email){
         //this code from internet "email Validation"
        //source https://www.javatpoint.com/java-email-validation
        //Regular Expression   
        String regex = "^[\\w!#$%&'*+/=?`{|}~^-]+(?:\\.[\\w!#$%&'*+/=?`{|}~^-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}";  
        //Compile regular expression to get the pattern  
        Pattern patternE = Pattern.compile(regex);   
         Matcher matcher = patternE.matcher(email);  
        // end code from internet
            if(matcher.matches()==true){
                return true;
            }
            else 
                return false;
    }
     public boolean passwordChecker(String password){
        //this code from internet "password Validation"
        //source https://java2blog.com/validate-password-java/
        String regex1 = "^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{8,20}$";
        Pattern patternP = Pattern.compile(regex1);
        Matcher matcherP = patternP.matcher(password);
            if(matcherP.matches()==true){
                return true;
            }
            else 
                return false;
    }
     public boolean ageChecker(String age){
         if (age.length() <= 2 & age.length() >0){
             return true;
         }
         else return false;
     }
     
}

