/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package who_inside;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.text.Text;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.animation.PauseTransition;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.media.AudioClip;
import javafx.stage.Stage;
import javafx.util.Duration;
import javax.swing.Timer;

/**
 * FXML Controller class
 *
 * @author Moon
 */
public class RememberController implements Initializable {

    @FXML
    private Text score;
    @FXML
    private Text time;
    @FXML
    private ComboBox<String> box1;
    @FXML
    private ComboBox<String> box2;
    @FXML
    private ComboBox<String> box3;
    @FXML
    private ComboBox<String> box4;
    @FXML
    private ComboBox<String> box5;
    @FXML
    private ComboBox<String> box6;
    @FXML
    private ComboBox<String> box7;
    @FXML
    private ComboBox<String> box8;
    @FXML
    private ComboBox<String> box9;
    @FXML
    private ComboBox<String> box10;
    
    ObservableList<String> list = FXCollections.observableArrayList("المخ","القلب","المريء","البنكرياس","الأمعاء الغليظة","الأمعاء الدقيقة","الرئتين","الكبد","الكلى","المعدة");
    
    boolean flage1=false;
    boolean flage2=false;
    boolean flage3=false;
    boolean flage4=false;
    boolean flage5=false;
    boolean flage6=false;
    boolean flage7=false;
    boolean flage8=false;
    boolean flage9=false;
    boolean flage10=false;
    
    int numScore;
    Timer timer;
    int second, minute;
    String ddSecond, ddMinute;
    DecimalFormat dFormat = new DecimalFormat("00");
    public static String scoreForBoardRember;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        box1.getItems().addAll(list);
        box2.getItems().addAll(list);
        box3.getItems().addAll(list);
        box4.getItems().addAll(list);
        box5.getItems().addAll(list);
        box6.getItems().addAll(list);
        box7.getItems().addAll(list);
        box8.getItems().addAll(list);
        box9.getItems().addAll(list);
        box10.getItems().addAll(list);
        
        // Countdown Timer
        time.setText("01:00");
        second =0;
        minute =1;
        countdownTimer();
        timer.start();	
    }
    //https://youtu.be/zWw72j-EbqI
    public void countdownTimer() {
		
		timer = new Timer(1000, new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				second--;
				ddSecond = dFormat.format(second);
				ddMinute = dFormat.format(minute);	
				time.setText(ddMinute + ":" + ddSecond);
				
				if(second==-1) {
					second = 59;
					minute--;
					ddSecond = dFormat.format(second);
					ddMinute = dFormat.format(minute);	
					time.setText(ddMinute + ":" + ddSecond);
				}
				if(minute==0 && second==0) {
                                    minute=0;
                                    second=0;
                                    timer.stop();    
				}
			}
		});
	}

    @FXML
    private void countScore1(javafx.event.ActionEvent event) throws IOException {
        if (minute==0 && second==0){
            Parent root = FXMLLoader.load(getClass().getResource("remember_lose.fxml"));
            Scene scene = new Scene(root);
            Stage stage=(Stage) ((Node)event.getSource()).getScene().getWindow();
            stage.setTitle("Oh Nooo !!!");
            stage.setScene(scene);
            stage.show();
            PauseTransition wait1 = new PauseTransition(Duration.seconds(1));
            wait1.setOnFinished(e -> {
                AudioClip  lose= new AudioClip(this.getClass().getResource("lose.m4a").toString());
                lose.play();
            });
            wait1.play();
            AudioClip  lose2= new AudioClip(this.getClass().getResource("for_lose.m4a").toString());
            lose2.setVolume(0.13);
            lose2.play();
        }
        if(box1.getValue()=="الكبد" && !flage1){
            numScore=Integer.valueOf(score.getText())+10;
            score.setText(String.valueOf(numScore));
            scoreForBoardRember=score.getText();
            flage1 = true;
            AudioClip  True= new AudioClip(this.getClass().getResource("true.m4a").toString());
            True.setVolume(0.15);
            True.play();
            if (numScore==100){
            Parent root = FXMLLoader.load(getClass().getResource("remember_win.fxml"));
            Scene scene = new Scene(root);
            Stage stage=(Stage) ((Node)event.getSource()).getScene().getWindow();
            stage.setTitle("Congratulations !!!");
            stage.setScene(scene);
            stage.show();
            PauseTransition wait1 = new PauseTransition(Duration.seconds(1));
            wait1.setOnFinished(e -> {
                AudioClip  win= new AudioClip(this.getClass().getResource("win.m4a").toString());
                win.play();
            });
            wait1.play();
            AudioClip  win2= new AudioClip(this.getClass().getResource("for_win.m4a").toString());
            win2.setVolume(0.13);
            win2.play();
        }
        }
        else{ 
            if(numScore==0){
            numScore=0;
            AudioClip  False= new AudioClip(this.getClass().getResource("false.m4a").toString());
            False.setVolume(0.1);
            False.play();
        }
        else {
                numScore=Integer.valueOf(score.getText())-10;
                score.setText(String.valueOf(numScore));
                scoreForBoardRember=score.getText();
                flage1=false;
                AudioClip  False= new AudioClip(this.getClass().getResource("false.m4a").toString());
                False.setVolume(0.1);
                False.play();
            }
        }
    }

    @FXML
    private void countScore2(javafx.event.ActionEvent event) throws IOException {
        if (minute==0 && second==0){
            Parent root = FXMLLoader.load(getClass().getResource("remember_lose.fxml"));
            Scene scene = new Scene(root);
            Stage stage=(Stage) ((Node)event.getSource()).getScene().getWindow();
            stage.setTitle("Oh Nooo !!!");
            stage.setScene(scene);
            stage.show();
            PauseTransition wait1 = new PauseTransition(Duration.seconds(1));
            wait1.setOnFinished(e -> {
                AudioClip  lose= new AudioClip(this.getClass().getResource("lose.m4a").toString());
                lose.play();
            });
            wait1.play();
            AudioClip  lose2= new AudioClip(this.getClass().getResource("for_lose.m4a").toString());
            lose2.setVolume(0.13);
            lose2.play();
        }
        if(box2.getValue()=="المعدة" && !flage2){
            numScore=Integer.valueOf(score.getText())+10;
            score.setText(String.valueOf(numScore));
            scoreForBoardRember=score.getText();
            flage2 = true;
            AudioClip  True= new AudioClip(this.getClass().getResource("true.m4a").toString());
            True.setVolume(0.15);
            True.play();
            if (numScore==100){
            Parent root = FXMLLoader.load(getClass().getResource("remember_win.fxml"));
            Scene scene = new Scene(root);
            Stage stage=(Stage) ((Node)event.getSource()).getScene().getWindow();
            stage.setTitle("Congratulations !!!");
            stage.setScene(scene);
            stage.show();
            PauseTransition wait1 = new PauseTransition(Duration.seconds(1));
            wait1.setOnFinished(e -> {
                AudioClip  win= new AudioClip(this.getClass().getResource("win.m4a").toString());
                win.play();
            });
            wait1.play();
            AudioClip  win2= new AudioClip(this.getClass().getResource("for_win.m4a").toString());
            win2.setVolume(0.13);
            win2.play();
        }
        }
        else{ 
            if(numScore==10){
            AudioClip  False= new AudioClip(this.getClass().getResource("false.m4a").toString());
            False.setVolume(0.1);
            False.play();
        }
        else if(numScore>10){
                numScore=Integer.valueOf(score.getText())-10;
                score.setText(String.valueOf(numScore));
                scoreForBoardRember=score.getText();
                flage2=false;
                AudioClip  False= new AudioClip(this.getClass().getResource("false.m4a").toString());
                False.setVolume(0.1);
                False.play();
            }
        }
    }

    @FXML
    private void countScore3(javafx.event.ActionEvent event) throws IOException {
        if (minute==0 && second==0){
            Parent root = FXMLLoader.load(getClass().getResource("remember_lose.fxml"));
            Scene scene = new Scene(root);
            Stage stage=(Stage) ((Node)event.getSource()).getScene().getWindow();
            stage.setTitle("Oh Nooo !!!");
            stage.setScene(scene);
            stage.show();
            PauseTransition wait1 = new PauseTransition(Duration.seconds(1));
            wait1.setOnFinished(e -> {
                AudioClip  lose= new AudioClip(this.getClass().getResource("lose.m4a").toString());
                lose.play();
            });
            wait1.play();
            AudioClip  lose2= new AudioClip(this.getClass().getResource("for_lose.m4a").toString());
            lose2.setVolume(0.13);
            lose2.play();
        }
        if(box3.getValue()=="المريء" && !flage3){
            numScore=Integer.valueOf(score.getText())+10;
            score.setText(String.valueOf(numScore));
            scoreForBoardRember=score.getText();
            flage3 = true;
            AudioClip  True= new AudioClip(this.getClass().getResource("true.m4a").toString());
            True.setVolume(0.15);
            True.play();
            if (numScore==100){
            Parent root = FXMLLoader.load(getClass().getResource("remember_win.fxml"));
            Scene scene = new Scene(root);
            Stage stage=(Stage) ((Node)event.getSource()).getScene().getWindow();
            stage.setTitle("Congratulations !!!");
            stage.setScene(scene);
            stage.show();
            PauseTransition wait1 = new PauseTransition(Duration.seconds(1));
            wait1.setOnFinished(e -> {
                AudioClip  win= new AudioClip(this.getClass().getResource("win.m4a").toString());
                win.play();
            });
            wait1.play();
            AudioClip  win2= new AudioClip(this.getClass().getResource("for_win.m4a").toString());
            win2.setVolume(0.13);
            win2.play();
        }
        }
        else{ 
            if(numScore==20){
             AudioClip  False= new AudioClip(this.getClass().getResource("false.m4a").toString());
             False.setVolume(0.1);
            False.play();
            }
        else if(numScore>20){
                numScore=Integer.valueOf(score.getText())-10;
                score.setText(String.valueOf(numScore));
                scoreForBoardRember=score.getText();
                flage3=false;
                AudioClip  False= new AudioClip(this.getClass().getResource("false.m4a").toString());
                False.setVolume(0.1);
                False.play();
            }
        }
    }

    @FXML
    private void countScore4(javafx.event.ActionEvent event) throws IOException {
        if (minute==0 && second==0){
            Parent root = FXMLLoader.load(getClass().getResource("remember_lose.fxml"));
            Scene scene = new Scene(root);
            Stage stage=(Stage) ((Node)event.getSource()).getScene().getWindow();
            stage.setTitle("Oh Nooo !!!");
            stage.setScene(scene);
            stage.show();
            PauseTransition wait1 = new PauseTransition(Duration.seconds(1));
            wait1.setOnFinished(e -> {
                AudioClip  lose= new AudioClip(this.getClass().getResource("lose.m4a").toString());
                lose.play();
            });
            wait1.play();
            AudioClip  lose2= new AudioClip(this.getClass().getResource("for_lose.m4a").toString());
            lose2.setVolume(0.13);
            lose2.play();
        }
        if(box4.getValue()=="الكلى" && !flage4){
            numScore=Integer.valueOf(score.getText())+10;
            score.setText(String.valueOf(numScore));
            scoreForBoardRember=score.getText();
            flage4 = true;
            AudioClip  True= new AudioClip(this.getClass().getResource("true.m4a").toString());
            True.setVolume(0.15);
            True.play();
            if (numScore==100){
            Parent root = FXMLLoader.load(getClass().getResource("remember_win.fxml"));
            Scene scene = new Scene(root);
            Stage stage=(Stage) ((Node)event.getSource()).getScene().getWindow();
            stage.setTitle("Congratulations !!!");
            stage.setScene(scene);
            stage.show();
            PauseTransition wait1 = new PauseTransition(Duration.seconds(1));
            wait1.setOnFinished(e -> {
                AudioClip  win= new AudioClip(this.getClass().getResource("win.m4a").toString());
                win.play();
            });
            wait1.play();
            AudioClip  win2= new AudioClip(this.getClass().getResource("for_win.m4a").toString());
            win2.setVolume(0.13);
            win2.play();
        }
        }
        else{ 
            if(numScore==30){
             AudioClip  False= new AudioClip(this.getClass().getResource("false.m4a").toString());
             False.setVolume(0.1);
            False.play();
            }
        else if(numScore>30){
                numScore=Integer.valueOf(score.getText())-10;
                score.setText(String.valueOf(numScore));
                scoreForBoardRember=score.getText();
                flage4=false;
                AudioClip  False= new AudioClip(this.getClass().getResource("false.m4a").toString());
                False.setVolume(0.1);
                False.play();
            }
        }
    }

    @FXML
    private void countScore5(javafx.event.ActionEvent event) throws IOException {
        if (minute==0 && second==0){
            Parent root = FXMLLoader.load(getClass().getResource("remember_lose.fxml"));
            Scene scene = new Scene(root);
            Stage stage=(Stage) ((Node)event.getSource()).getScene().getWindow();
            stage.setTitle("Oh Nooo !!!");
            stage.setScene(scene);
            stage.show();
            PauseTransition wait1 = new PauseTransition(Duration.seconds(1));
            wait1.setOnFinished(e -> {
                AudioClip  lose= new AudioClip(this.getClass().getResource("lose.m4a").toString());
                lose.play();
            });
            wait1.play();
            AudioClip  lose2= new AudioClip(this.getClass().getResource("for_lose.m4a").toString());
            lose2.setVolume(0.13);
            lose2.play();
        }
        if(box5.getValue()=="الأمعاء الغليظة" && !flage5){
            numScore=Integer.valueOf(score.getText())+10;
            score.setText(String.valueOf(numScore));
            scoreForBoardRember=score.getText();
            flage5 = true;
            AudioClip  True= new AudioClip(this.getClass().getResource("true.m4a").toString());
            True.setVolume(0.15);
            True.play();
            if (numScore==100){
            Parent root = FXMLLoader.load(getClass().getResource("remember_win.fxml"));
            Scene scene = new Scene(root);
            Stage stage=(Stage) ((Node)event.getSource()).getScene().getWindow();
            stage.setTitle("Congratulations !!!");
            stage.setScene(scene);
            stage.show();
            PauseTransition wait1 = new PauseTransition(Duration.seconds(1));
            wait1.setOnFinished(e -> {
                AudioClip  win= new AudioClip(this.getClass().getResource("win.m4a").toString());
                win.play();
            });
            wait1.play();
            AudioClip  win2= new AudioClip(this.getClass().getResource("for_win.m4a").toString());
            win2.setVolume(0.13);
            win2.play();
        }}
        else{ 
            if(numScore==40){
             AudioClip  False= new AudioClip(this.getClass().getResource("false.m4a").toString());
             False.setVolume(0.1);
            False.play();
            }
        else if(numScore>40){
                numScore=Integer.valueOf(score.getText())-10;
                score.setText(String.valueOf(numScore));
                scoreForBoardRember=score.getText();
                flage5=false;
                AudioClip  False= new AudioClip(this.getClass().getResource("false.m4a").toString());
                False.setVolume(0.1);
                False.play();
            }
        }
    }

    @FXML
    private void countScore6(javafx.event.ActionEvent event) throws IOException {
        if (minute==0 && second==0){
            Parent root = FXMLLoader.load(getClass().getResource("remember_lose.fxml"));
            Scene scene = new Scene(root);
            Stage stage=(Stage) ((Node)event.getSource()).getScene().getWindow();
            stage.setTitle("Oh Nooo !!!");
            stage.setScene(scene);
            stage.show();
            PauseTransition wait1 = new PauseTransition(Duration.seconds(1));
            wait1.setOnFinished(e -> {
                AudioClip  lose= new AudioClip(this.getClass().getResource("lose.m4a").toString());
                lose.play();
            });
            wait1.play();
            AudioClip  lose2= new AudioClip(this.getClass().getResource("for_lose.m4a").toString());
            lose2.setVolume(0.13);
            lose2.play();
        }
        if(box6.getValue()=="القلب" && !flage6){
            numScore=Integer.valueOf(score.getText())+10;
            score.setText(String.valueOf(numScore));
            scoreForBoardRember=score.getText();
            flage6 = true;
            AudioClip  True= new AudioClip(this.getClass().getResource("true.m4a").toString());
            True.setVolume(0.15);
            True.play();
            if (numScore==100){
            Parent root = FXMLLoader.load(getClass().getResource("remember_win.fxml"));
            Scene scene = new Scene(root);
            Stage stage=(Stage) ((Node)event.getSource()).getScene().getWindow();
            stage.setTitle("Congratulations !!!");
            stage.setScene(scene);
            stage.show();
            PauseTransition wait1 = new PauseTransition(Duration.seconds(1));
            wait1.setOnFinished(e -> {
                AudioClip  win= new AudioClip(this.getClass().getResource("win.m4a").toString());
                win.play();
            });
            wait1.play();
            AudioClip  win2= new AudioClip(this.getClass().getResource("for_win.m4a").toString());
            win2.setVolume(0.13);
            win2.play();
        }}
        else{ 
            if(numScore==50){
             AudioClip  False= new AudioClip(this.getClass().getResource("false.m4a").toString());
             False.setVolume(0.1);
            False.play();
            }
        else if(numScore>50){
                numScore=Integer.valueOf(score.getText())-10;
                score.setText(String.valueOf(numScore));
                scoreForBoardRember=score.getText();
                flage6=false;
                AudioClip  False= new AudioClip(this.getClass().getResource("false.m4a").toString());
                False.setVolume(0.1);
                False.play();
            }
        }
    }

    @FXML
    private void countScore7(javafx.event.ActionEvent event) throws IOException {
        if (minute==0 && second==0){
            Parent root = FXMLLoader.load(getClass().getResource("remember_lose.fxml"));
            Scene scene = new Scene(root);
            Stage stage=(Stage) ((Node)event.getSource()).getScene().getWindow();
            stage.setTitle("Oh Nooo !!!");
            stage.setScene(scene);
            stage.show();
            PauseTransition wait1 = new PauseTransition(Duration.seconds(1));
            wait1.setOnFinished(e -> {
                AudioClip  lose= new AudioClip(this.getClass().getResource("lose.m4a").toString());
                lose.play();
            });
            wait1.play();
            AudioClip  lose2= new AudioClip(this.getClass().getResource("for_lose.m4a").toString());
            lose2.setVolume(0.13);
            lose2.play();
        }
        if(box7.getValue()=="المخ" && !flage7){
            numScore=Integer.valueOf(score.getText())+10;
            score.setText(String.valueOf(numScore));
            scoreForBoardRember=score.getText();
            flage7 = true;
            AudioClip  True= new AudioClip(this.getClass().getResource("true.m4a").toString());
            True.setVolume(0.15);
            True.play();
            if (numScore==100){
            Parent root = FXMLLoader.load(getClass().getResource("remember_win.fxml"));
            Scene scene = new Scene(root);
            Stage stage=(Stage) ((Node)event.getSource()).getScene().getWindow();
            stage.setTitle("Congratulations !!!");
            stage.setScene(scene);
            stage.show();
            PauseTransition wait1 = new PauseTransition(Duration.seconds(1));
            wait1.setOnFinished(e -> {
                AudioClip  win= new AudioClip(this.getClass().getResource("win.m4a").toString());
                win.play();
            });
            wait1.play();
            AudioClip  win2= new AudioClip(this.getClass().getResource("for_win.m4a").toString());
            win2.setVolume(0.13);
            win2.play();
        }}
        else{ 
            if(numScore==60){
             AudioClip  False= new AudioClip(this.getClass().getResource("false.m4a").toString());
             False.setVolume(0.1);
            False.play();
            }
        else if(numScore>60){
                numScore=Integer.valueOf(score.getText())-10;
                score.setText(String.valueOf(numScore));
                scoreForBoardRember=score.getText();
                flage7=false;
                AudioClip  False= new AudioClip(this.getClass().getResource("false.m4a").toString());
                False.setVolume(0.1);
                False.play();
            }
        }
    }

    @FXML
    private void countScore8(javafx.event.ActionEvent event) throws IOException {
        if (minute==0 && second==0){
            Parent root = FXMLLoader.load(getClass().getResource("remember_lose.fxml"));
            Scene scene = new Scene(root);
            Stage stage=(Stage) ((Node)event.getSource()).getScene().getWindow();
            stage.setTitle("Oh Nooo !!!");
            stage.setScene(scene);
            stage.show();
            PauseTransition wait1 = new PauseTransition(Duration.seconds(1));
            wait1.setOnFinished(e -> {
                AudioClip  lose= new AudioClip(this.getClass().getResource("lose.m4a").toString());
                lose.play();
            });
            wait1.play();
            AudioClip  lose2= new AudioClip(this.getClass().getResource("for_lose.m4a").toString());
            lose2.setVolume(0.13);
            lose2.play();
        }
         if(box8.getValue()=="الأمعاء الدقيقة" && !flage8){
            numScore=Integer.valueOf(score.getText())+10;
            score.setText(String.valueOf(numScore));
            scoreForBoardRember=score.getText();
            flage8 = true;
            AudioClip  True= new AudioClip(this.getClass().getResource("true.m4a").toString());
            True.setVolume(0.15);
            True.play();
            if (numScore==100){
            Parent root = FXMLLoader.load(getClass().getResource("remember_win.fxml"));
            Scene scene = new Scene(root);
            Stage stage=(Stage) ((Node)event.getSource()).getScene().getWindow();
            stage.setTitle("Congratulations !!!");
            stage.setScene(scene);
            stage.show();
            PauseTransition wait1 = new PauseTransition(Duration.seconds(1));
            wait1.setOnFinished(e -> {
                AudioClip  win= new AudioClip(this.getClass().getResource("win.m4a").toString());
                win.play();
            });
            wait1.play();
            AudioClip  win2= new AudioClip(this.getClass().getResource("for_win.m4a").toString());
            win2.setVolume(0.13);
            win2.play();
        }}
         else{ 
            if(numScore==70){
             AudioClip  False= new AudioClip(this.getClass().getResource("false.m4a").toString());
             False.setVolume(0.1);
            False.play();
            }
        else if(numScore>70){
                numScore=Integer.valueOf(score.getText())-10;
                score.setText(String.valueOf(numScore));
                scoreForBoardRember=score.getText();
                flage8=false;
                AudioClip  False= new AudioClip(this.getClass().getResource("false.m4a").toString());
                False.setVolume(0.1);
                False.play();
            }
         }
    }

    @FXML
    private void countScore9(javafx.event.ActionEvent event) throws IOException {
        if (minute==0 && second==0){
            Parent root = FXMLLoader.load(getClass().getResource("remember_lose.fxml"));
            Scene scene = new Scene(root);
            Stage stage=(Stage) ((Node)event.getSource()).getScene().getWindow();
            stage.setTitle("Oh Nooo !!!");
            stage.setScene(scene);
            stage.show();
            PauseTransition wait1 = new PauseTransition(Duration.seconds(1));
            wait1.setOnFinished(e -> {
                AudioClip  lose= new AudioClip(this.getClass().getResource("lose.m4a").toString());
                lose.play();
            });
            wait1.play();
            AudioClip  lose2= new AudioClip(this.getClass().getResource("for_lose.m4a").toString());
            lose2.setVolume(0.13);
            lose2.play();
        }
        if(box9.getValue()=="الرئتين" && !flage9){
            numScore=Integer.valueOf(score.getText())+10;
            score.setText(String.valueOf(numScore));
            scoreForBoardRember=score.getText();
            flage9 = true;
            AudioClip  True= new AudioClip(this.getClass().getResource("true.m4a").toString());
            True.setVolume(0.15);
            True.play();
            if (numScore==100){
            Parent root = FXMLLoader.load(getClass().getResource("remember_win.fxml"));
            Scene scene = new Scene(root);
            Stage stage=(Stage) ((Node)event.getSource()).getScene().getWindow();
            stage.setTitle("Congratulations !!!");
            stage.setScene(scene);
            stage.show();
            PauseTransition wait1 = new PauseTransition(Duration.seconds(1));
            wait1.setOnFinished(e -> {
                AudioClip  win= new AudioClip(this.getClass().getResource("win.m4a").toString());
                win.play();
            });
            wait1.play();
            AudioClip  win2= new AudioClip(this.getClass().getResource("for_win.m4a").toString());
            win2.setVolume(0.13);
            win2.play();
        }}
        else{ 
            if(numScore==80){
             AudioClip  False= new AudioClip(this.getClass().getResource("false.m4a").toString());
             False.setVolume(0.1);
            False.play();
            }
        else if(numScore>80){
                numScore=Integer.valueOf(score.getText())-10;
                score.setText(String.valueOf(numScore));
                scoreForBoardRember=score.getText();
                flage9=false;
                AudioClip  False= new AudioClip(this.getClass().getResource("false.m4a").toString());
                False.setVolume(0.1);
                False.play();
            }
        }
    }

    @FXML
    private void countScore10(javafx.event.ActionEvent event) throws IOException {
        if (minute==0 && second==0){
            Parent root = FXMLLoader.load(getClass().getResource("remember_lose.fxml"));
            Scene scene = new Scene(root);
            Stage stage=(Stage) ((Node)event.getSource()).getScene().getWindow();
            stage.setTitle("Oh Nooo !!!");
            stage.setScene(scene);
            stage.show();
            PauseTransition wait1 = new PauseTransition(Duration.seconds(1));
            wait1.setOnFinished(e -> {
                AudioClip  lose= new AudioClip(this.getClass().getResource("lose.m4a").toString());
                lose.play();
            });
            wait1.play();
            AudioClip  lose2= new AudioClip(this.getClass().getResource("for_lose.m4a").toString());
            lose2.setVolume(0.13);
            lose2.play();
        }
        if(box10.getValue()=="البنكرياس" && !flage10){
            numScore=Integer.valueOf(score.getText())+10;
            score.setText(String.valueOf(numScore));
            scoreForBoardRember=score.getText();
            flage10 = true;
            AudioClip  True= new AudioClip(this.getClass().getResource("true.m4a").toString());
            True.setVolume(0.15);
            True.play();
            if (numScore==100){
            Parent root = FXMLLoader.load(getClass().getResource("remember_win.fxml"));
            Scene scene = new Scene(root);
            Stage stage=(Stage) ((Node)event.getSource()).getScene().getWindow();
            stage.setTitle("Congratulations !!!");
            stage.setScene(scene);
            stage.show();
            PauseTransition wait1 = new PauseTransition(Duration.seconds(1));
            wait1.setOnFinished(e -> {
                AudioClip  win= new AudioClip(this.getClass().getResource("win.m4a").toString());
                win.play();
            });
            wait1.play();
            AudioClip  win2= new AudioClip(this.getClass().getResource("for_win.m4a").toString());
            win2.setVolume(0.13);
            win2.play();
        }}
        else{ 
            if(numScore==90){
             AudioClip  False= new AudioClip(this.getClass().getResource("false.m4a").toString());
             False.setVolume(0.1);
            False.play();
            }
        else if(numScore>90){
                numScore=Integer.valueOf(score.getText())-10;
                score.setText(String.valueOf(numScore));
                scoreForBoardRember=score.getText();
                flage10=false;
                AudioClip  False= new AudioClip(this.getClass().getResource("false.m4a").toString());
                False.setVolume(0.1);
                False.play();
            }
        }
    }
    
}
