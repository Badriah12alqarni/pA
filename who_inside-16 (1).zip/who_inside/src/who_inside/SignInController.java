/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package who_inside;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.List;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 * FXML Controller class
 *
 * @author rahafibrahim
 */

public class SignInController implements Initializable {

   

    @FXML
    private TextField tfUserName;
    @FXML
    private TextField tfPassword;
    @FXML
    private Button btNext;
    @FXML
    private Button btnSignUp;
     @FXML
    private Label lbMsg;
public static String us;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void btNextAction(ActionEvent event) throws IOException {
        String emptyUser=tfUserName.getText();
        String emptyPassword=tfPassword.getText();
        
         Session session = HibernateUtil.getSessionFactory().openSession();
        List<User> lList = null;
        String queryStr = "from User";
        Query query = session.createQuery(queryStr);
        lList = query.list();
        session.close();
        boolean find = false;
        for(User l: lList)
        {
            if(l.getUsername().equals(tfUserName.getText()) & l.getPassword().equals(tfPassword.getText())){
                find= true;
                break;
            }
            
        }
        if(find){
         us=tfUserName.getText();
         lbMsg.setText("... أهلا بك");
         
         Parent root = FXMLLoader.load(getClass().getResource("level.fxml"));
        Scene scene = new Scene(root);
        Stage stage=(Stage) ((Node)event.getSource()).getScene().getWindow();
        stage.setTitle("Level");
        stage.setScene(scene);
        stage.show();
       }
        else 
            if(emptyUser.isEmpty() || emptyPassword.isEmpty())
                lbMsg.setText("الرجاء ملء جميع الحقول");
            else
                lbMsg.setText("اسم المستخدم أو كلمة المرور خاطئ");
    
    
        
    }

    @FXML
    private void setSignUp(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("signUp.fxml"));
        Scene scene = new Scene(root);
        Stage stage=(Stage) ((Node)event.getSource()).getScene().getWindow();
        stage.setTitle("Sign up");
        stage.setScene(scene);
        stage.show();
    }

}
