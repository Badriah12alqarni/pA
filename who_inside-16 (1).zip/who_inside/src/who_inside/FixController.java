/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package who_inside;

import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.URL;
import java.text.DecimalFormat;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.animation.PauseTransition;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.ClipboardContent;
import javafx.scene.input.DragEvent;
import javafx.scene.input.Dragboard;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.TransferMode;
import javafx.scene.layout.VBox;
import javafx.scene.media.AudioClip;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Duration;
import javax.swing.Timer;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import static who_inside.FixController.scoreForBoard;
import static who_inside.SignInController.us;

/**
 * FXML Controller class
 *
 * @author rahafibrahim
 */
public class FixController implements Initializable {

    @FXML
    private ImageView lungsSet;
    @FXML
    private Button btPrePage;
    @FXML
    private ImageView heartSet;
    @FXML
    private ImageView brainSet;
    @FXML
    private ImageView stomachSet;
    @FXML
    private ImageView stomachGet;
    @FXML
    private ImageView brainGet;
    @FXML
    private ImageView heartGet;
    @FXML
    private ImageView lungsGet;
    @FXML
    private ImageView background;
    @FXML
    private ImageView intestinesLargSet;
    @FXML
    private ImageView intestinesLargeGet;
    @FXML
    private ImageView esophagusGet;
    @FXML
    private ImageView penGet;
    @FXML
    private ImageView smallintestiGet;
    @FXML
    private ImageView kidneysGett;
    @FXML
    private ImageView liverSet;
    @FXML
    private ImageView penSet;
    @FXML
    private ImageView kidneysSet;
    @FXML
    private ImageView smallintestineSet;
    @FXML
    private ImageView esophagusSet;
    @FXML
    private ImageView liverGet1;
    @FXML
    private Text score;
    @FXML
    private Text time;
    
    
    boolean flage1=false;
    boolean flage2=false;
    boolean flage3=false;
    boolean flage4=false;
    boolean flage5=false;
    boolean flage6=false;
    boolean flage7=false;
    boolean flage8=false;
    boolean flage9=false;
    boolean flage10=false;
     
    int numScore;
    Timer timer;
    int second, minute;
    String ddSecond, ddMinute;
    DecimalFormat dFormat = new DecimalFormat("00");
    public static String scoreForBoard;
    SignInController in=new SignInController();
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Countdown Timer
        time.setText("01:00");
        second =0;
        minute =1;
        countdownTimer();
        timer.start();	
        // TODO
       
        
       
    } 
    public void countdownTimer() {
		
		timer = new Timer(1000, new ActionListener() {
			
			@Override
			public void actionPerformed(java.awt.event.ActionEvent e) {
				
				second--;
				ddSecond = dFormat.format(second);
				ddMinute = dFormat.format(minute);	
				time.setText(ddMinute + ":" + ddSecond);
				
				if(second==-1) {
					second = 59;
					minute--;
					ddSecond = dFormat.format(second);
					ddMinute = dFormat.format(minute);	
					time.setText(ddMinute + ":" + ddSecond);
				}
				if(minute==0 && second==0) {
                                    minute=0;
                                    second=0;
                                    timer.stop();    
				}
			}
		});
	}

    @FXML
    private void stomachSetDet(MouseEvent event) throws IOException {
       
  
          if (minute==0 && second==0){
            Parent root;
              try {
                  root = FXMLLoader.load(getClass().getResource("fix_lose.fxml"));
                  Scene scene = new Scene(root);
            Stage stage=(Stage) ((Node)event.getSource()).getScene().getWindow();
            stage.setTitle("Oh Nooo !!!");
            stage.setScene(scene);
            stage.show();
            PauseTransition wait1 = new PauseTransition(Duration.seconds(1));
            wait1.setOnFinished(e -> {
                AudioClip  lose= new AudioClip(this.getClass().getResource("lose.m4a").toString());
                lose.play();
            });
            wait1.play();
            AudioClip  lose2= new AudioClip(this.getClass().getResource("for_lose.m4a").toString());
            lose2.setVolume(0.13);
            lose2.play();
              } catch (IOException ex) {
                  Logger.getLogger(FixController.class.getName()).log(Level.SEVERE, null, ex);
              }
            
        }
             else{
        Dragboard db = stomachSet.startDragAndDrop(TransferMode.ANY);
        ClipboardContent content = new ClipboardContent();
        content.putImage(stomachSet.getImage());
        db.setContent(content);
        event.consume();
          }
  

    }

    @FXML        //1
    private void stomachSetDone(DragEvent event) throws IOException {
        


            Dragboard db = event.getDragboard();

           if (db.hasImage()&& !flage1) {
               stomachGet.setImage(db.getImage());
               
               numScore = Integer.valueOf(score.getText()) + 10;
               score.setText(String.valueOf(numScore));
               scoreForBoard=score.getText(); 
               flage1 = true;
               AudioClip  True= new AudioClip(this.getClass().getResource("true.m4a").toString());
               True.setVolume(0.15);
               True.play();
              
            if (numScore==100){
            
            Parent root;
                    try {
                        root = FXMLLoader.load(getClass().getResource("fix_win.fxml"));

                        Scene scene = new Scene(root);
                        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                        stage.setTitle("Congratulations !!!");
                        stage.setScene(scene);
                        stage.show();
                        PauseTransition wait1 = new PauseTransition(Duration.seconds(1));
                        wait1.setOnFinished(e -> {
                            AudioClip  win= new AudioClip(this.getClass().getResource("win.m4a").toString());
                            win.play();
                        });
                        wait1.play();
                        AudioClip  win2= new AudioClip(this.getClass().getResource("for_win.m4a").toString());
                        win2.setVolume(0.13);
                        win2.play();
                        
                    } catch (IOException ex) {
                        Logger.getLogger(FixController.class.getName()).log(Level.SEVERE, null, ex);
                    }
            }
           
          
            }
           event.consume(); 
 
        }
  


    @FXML
    private void lungsDetected(MouseEvent event) {
       
              if (minute==0 && second==0){
            Parent root;
              try {
                  root = FXMLLoader.load(getClass().getResource("fix_lose.fxml"));
                  Scene scene = new Scene(root);
            Stage stage=(Stage) ((Node)event.getSource()).getScene().getWindow();
            stage.setTitle("Oh Nooo !!!");
            stage.setScene(scene);
            stage.show();
            PauseTransition wait1 = new PauseTransition(Duration.seconds(1));
            wait1.setOnFinished(e -> {
                AudioClip  lose= new AudioClip(this.getClass().getResource("lose.m4a").toString());
                lose.play();
            });
            wait1.play();
            AudioClip  lose2= new AudioClip(this.getClass().getResource("for_lose.m4a").toString());
            lose2.setVolume(0.13);
            lose2.play();
              } catch (IOException ex) {
                  Logger.getLogger(FixController.class.getName()).log(Level.SEVERE, null, ex);
              }
            
        }
             else{
        Dragboard db = lungsSet.startDragAndDrop(TransferMode.ANY);
        ClipboardContent content = new ClipboardContent();
        content.putImage(lungsSet.getImage());
        db.setContent(content);
        event.consume();
              }
   
    }

    @FXML        //2
    private void lungsDone(DragEvent event) {
        

            Dragboard db = event.getDragboard();

           if (db.hasImage() && !flage2) {
                lungsGet.setImage(db.getImage());
                               numScore = Integer.valueOf(score.getText()) + 10;
               score.setText(String.valueOf(numScore));
               scoreForBoard=score.getText();
               flage2 = true;
               AudioClip  True= new AudioClip(this.getClass().getResource("true.m4a").toString());
               True.setVolume(0.15);
               True.play();
            if (numScore==100){
            Parent root;
                    try {
                        root = FXMLLoader.load(getClass().getResource("fix_win.fxml"));

                        Scene scene = new Scene(root);
                        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                        stage.setTitle("Congratulations !!!");
                        stage.setScene(scene);
                        stage.show();
                        PauseTransition wait1 = new PauseTransition(Duration.seconds(1));
                        wait1.setOnFinished(e -> {
                            AudioClip  win= new AudioClip(this.getClass().getResource("win.m4a").toString());
                            win.play();
                        });
                        wait1.play();
                        AudioClip  win2= new AudioClip(this.getClass().getResource("for_win.m4a").toString());
                        win2.setVolume(0.13);
                        win2.play();
                    } catch (IOException ex) {
                        Logger.getLogger(FixController.class.getName()).log(Level.SEVERE, null, ex);
                    }
                System.out.println("drag done ......lungs ");
            }
           }
           
             event.consume(); 

        }
   
         
        

    @FXML
    private void heartDetected(MouseEvent event) {
    
             if (minute==0 && second==0){
            Parent root;
              try {
                  root = FXMLLoader.load(getClass().getResource("fix_lose.fxml"));
                  Scene scene = new Scene(root);
            Stage stage=(Stage) ((Node)event.getSource()).getScene().getWindow();
            stage.setTitle("Oh Nooo !!!");
            stage.setScene(scene);
            stage.show();
            PauseTransition wait1 = new PauseTransition(Duration.seconds(1));
            wait1.setOnFinished(e -> {
                AudioClip  lose= new AudioClip(this.getClass().getResource("lose.m4a").toString());
                lose.play();
            });
            wait1.play();
            AudioClip  lose2= new AudioClip(this.getClass().getResource("for_lose.m4a").toString());
            lose2.setVolume(0.13);
            lose2.play();
              } catch (IOException ex) {
                  Logger.getLogger(FixController.class.getName()).log(Level.SEVERE, null, ex);
              }
            
        }
             else{
        Dragboard db = heartSet.startDragAndDrop(TransferMode.ANY);
        ClipboardContent content = new ClipboardContent();
        content.putImage(heartSet.getImage());
        db.setContent(content);
        event.consume();
             }
    }

    @FXML        //3
    private void heartDone(DragEvent event) {
         
       

            Dragboard db = event.getDragboard();

           if (db.hasImage()&& !flage3) {
                heartGet.setImage(db.getImage());
                  numScore = Integer.valueOf(score.getText()) + 10;
               score.setText(String.valueOf(numScore));
               scoreForBoard=score.getText();
               flage3 = true;
            AudioClip  True= new AudioClip(this.getClass().getResource("true.m4a").toString());
            True.setVolume(0.15);
            True.play();
            if (numScore==100){
            Parent root;
                    try {
                        root = FXMLLoader.load(getClass().getResource("fix_win.fxml"));

                        Scene scene = new Scene(root);
                        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                        stage.setTitle("Congratulations !!!");
                        stage.setScene(scene);
                        stage.show();
                        PauseTransition wait1 = new PauseTransition(Duration.seconds(1));
                        wait1.setOnFinished(e -> {
                            AudioClip  win= new AudioClip(this.getClass().getResource("win.m4a").toString());
                            win.play();
                        });
                        wait1.play();
                        AudioClip  win2= new AudioClip(this.getClass().getResource("for_win.m4a").toString());
                        win2.setVolume(0.13);
                        win2.play();
                    } catch (IOException ex) {
                        Logger.getLogger(FixController.class.getName()).log(Level.SEVERE, null, ex);
                    }
                System.out.println("drag done ......lungs ");
            }
           }
           
             event.consume(); 

        }

    

    @FXML
    private void LargeDetected(MouseEvent event) {
       
             if (minute==0 && second==0){
            Parent root;
              try {
                  root = FXMLLoader.load(getClass().getResource("fix_lose.fxml"));
                  Scene scene = new Scene(root);
            Stage stage=(Stage) ((Node)event.getSource()).getScene().getWindow();
            stage.setTitle("Oh Nooo !!!");
            stage.setScene(scene);
            stage.show();
            PauseTransition wait1 = new PauseTransition(Duration.seconds(1));
            wait1.setOnFinished(e -> {
                AudioClip  lose= new AudioClip(this.getClass().getResource("lose.m4a").toString());
                lose.play();
            });
            wait1.play();
            AudioClip  lose2= new AudioClip(this.getClass().getResource("for_lose.m4a").toString());
            lose2.setVolume(0.13);
            lose2.play();
              } catch (IOException ex) {
                  Logger.getLogger(FixController.class.getName()).log(Level.SEVERE, null, ex);
              }
            
        }
             else{
        Dragboard db = intestinesLargSet.startDragAndDrop(TransferMode.ANY);
        ClipboardContent content = new ClipboardContent();
        content.putImage(intestinesLargSet.getImage());
        db.setContent(content);
        event.consume();
             }
 
    }

    @FXML       //4
    private void LargeDone(DragEvent event) {
        
            Dragboard db = event.getDragboard();

           if (db.hasImage()&& !flage4) {
                intestinesLargeGet.setImage(db.getImage());
                  numScore = Integer.valueOf(score.getText()) + 10;
               score.setText(String.valueOf(numScore));
               scoreForBoard=score.getText();
               flage4 = true;
            AudioClip  True= new AudioClip(this.getClass().getResource("true.m4a").toString());
            True.setVolume(0.15);
            True.play();
            if (numScore==100){
            Parent root;
                    try {
                        root = FXMLLoader.load(getClass().getResource("fix_win.fxml"));

                        Scene scene = new Scene(root);
                        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                        stage.setTitle("Congratulations !!!");
                        stage.setScene(scene);
                        stage.show();
                        PauseTransition wait1 = new PauseTransition(Duration.seconds(1));
                        wait1.setOnFinished(e -> {
                            AudioClip  win= new AudioClip(this.getClass().getResource("win.m4a").toString());
                            win.play();
                        });
                        wait1.play();
                        AudioClip  win2= new AudioClip(this.getClass().getResource("for_win.m4a").toString());
                        win2.setVolume(0.13);
                        win2.play();
                    } catch (IOException ex) {
                        Logger.getLogger(FixController.class.getName()).log(Level.SEVERE, null, ex);
                    }
                System.out.println("drag done ......lungs ");
            }
           }
           
             event.consume(); 

        }
 
    

    @FXML
    private void brainDetected(MouseEvent event) {
        
             if (minute==0 && second==0){
            Parent root;
              try {
                  root = FXMLLoader.load(getClass().getResource("fix_lose.fxml"));
                  Scene scene = new Scene(root);
            Stage stage=(Stage) ((Node)event.getSource()).getScene().getWindow();
            stage.setTitle("Oh Nooo !!!");
            stage.setScene(scene);
            stage.show();
            PauseTransition wait1 = new PauseTransition(Duration.seconds(1));
            wait1.setOnFinished(e -> {
                AudioClip  lose= new AudioClip(this.getClass().getResource("lose.m4a").toString());
                lose.play();
            });
            wait1.play();
            AudioClip  lose2= new AudioClip(this.getClass().getResource("for_lose.m4a").toString());
            lose2.setVolume(0.13);
            lose2.play();
              } catch (IOException ex) {
                  Logger.getLogger(FixController.class.getName()).log(Level.SEVERE, null, ex);
              }
            
        }
             else{
        Dragboard db = brainSet.startDragAndDrop(TransferMode.ANY);
        ClipboardContent content = new ClipboardContent();
        content.putImage(brainSet.getImage());
        db.setContent(content);
        event.consume();
             }
  
    }

    @FXML        //5
    private void brainDone(DragEvent event) {
       

            Dragboard db = event.getDragboard();

           if (db.hasImage()&& !flage5) {
                brainGet.setImage(db.getImage());
                  numScore = Integer.valueOf(score.getText()) + 10;
               score.setText(String.valueOf(numScore));
               scoreForBoard=score.getText();
               flage5 = true;
            AudioClip  True= new AudioClip(this.getClass().getResource("true.m4a").toString());
            True.setVolume(0.15);
            True.play();
            if (numScore==100){
            Parent root;
                    try {
                        root = FXMLLoader.load(getClass().getResource("fix_win.fxml"));

                        Scene scene = new Scene(root);
                        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                        stage.setTitle("Congratulations !!!");
                        stage.setScene(scene);
                        stage.show();
                        PauseTransition wait1 = new PauseTransition(Duration.seconds(1));
                        wait1.setOnFinished(e -> {
                            AudioClip  win= new AudioClip(this.getClass().getResource("win.m4a").toString());
                            win.play();
                        });
                        wait1.play();
                        AudioClip  win2= new AudioClip(this.getClass().getResource("for_win.m4a").toString());
                        win2.setVolume(0.13);
                        win2.play();
                    } catch (IOException ex) {
                        Logger.getLogger(FixController.class.getName()).log(Level.SEVERE, null, ex);
                    }
                System.out.println("drag done ......lungs ");
            }
           }
           
             event.consume(); 

        }
   
    @FXML
    private void liverDetcted(MouseEvent event) {
        
             if (minute==0 && second==0){
            Parent root;
              try {
                  root = FXMLLoader.load(getClass().getResource("fix_lose.fxml"));
                  Scene scene = new Scene(root);
            Stage stage=(Stage) ((Node)event.getSource()).getScene().getWindow();
            stage.setTitle("Oh Nooo !!!");
            stage.setScene(scene);
            stage.show();
            PauseTransition wait1 = new PauseTransition(Duration.seconds(1));
            wait1.setOnFinished(e -> {
                AudioClip  lose= new AudioClip(this.getClass().getResource("lose.m4a").toString());
                lose.play();
            });
            wait1.play();
            AudioClip  lose2= new AudioClip(this.getClass().getResource("for_lose.m4a").toString());
            lose2.setVolume(0.13);
            lose2.play();
              } catch (IOException ex) {
                  Logger.getLogger(FixController.class.getName()).log(Level.SEVERE, null, ex);
              }
            
        }
             else{
        Dragboard db = liverSet.startDragAndDrop(TransferMode.ANY);
        ClipboardContent content = new ClipboardContent();
        content.putImage(liverSet.getImage());
        db.setContent(content);
        event.consume();
             }
   
    }

    @FXML        //6
    private void liverDone(DragEvent event) {
       

            Dragboard db = event.getDragboard();

           if (db.hasImage()&& !flage6) {
                liverGet1.setImage(db.getImage());
                   numScore = Integer.valueOf(score.getText()) + 10;
               score.setText(String.valueOf(numScore));
               scoreForBoard=score.getText();
               flage6 = true;
            AudioClip  True= new AudioClip(this.getClass().getResource("true.m4a").toString());
            True.setVolume(0.15);
            True.play();
            if (numScore==100){
            Parent root;
                    try {
                        root = FXMLLoader.load(getClass().getResource("fix_win.fxml"));

                        Scene scene = new Scene(root);
                        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                        stage.setTitle("Congratulations !!!");
                        stage.setScene(scene);
                        stage.show();
                        PauseTransition wait1 = new PauseTransition(Duration.seconds(1));
                        wait1.setOnFinished(e -> {
                            AudioClip  win= new AudioClip(this.getClass().getResource("win.m4a").toString());
                            win.play();
                        });
                        wait1.play();
                        AudioClip  win2= new AudioClip(this.getClass().getResource("for_win.m4a").toString());
                        win2.setVolume(0.13);
                        win2.play();
                    } catch (IOException ex) {
                        Logger.getLogger(FixController.class.getName()).log(Level.SEVERE, null, ex);
                    }
                System.out.println("drag done ......lungs ");
            }
           }
           
             event.consume(); 

        }
  
    @FXML
    private void penDetected(MouseEvent event) {
       
             if (minute==0 && second==0){
            Parent root;
              try {
                  root = FXMLLoader.load(getClass().getResource("fix_lose.fxml"));
                  Scene scene = new Scene(root);
            Stage stage=(Stage) ((Node)event.getSource()).getScene().getWindow();
            stage.setTitle("Oh Nooo !!!");
            stage.setScene(scene);
            stage.show();
            PauseTransition wait1 = new PauseTransition(Duration.seconds(1));
            wait1.setOnFinished(e -> {
                AudioClip  lose= new AudioClip(this.getClass().getResource("lose.m4a").toString());
                lose.play();
            });
            wait1.play();
            AudioClip  lose2= new AudioClip(this.getClass().getResource("for_lose.m4a").toString());
            lose2.setVolume(0.13);
            lose2.play();
              } catch (IOException ex) {
                  Logger.getLogger(FixController.class.getName()).log(Level.SEVERE, null, ex);
              }
            
        }
             else{
        Dragboard db = penSet.startDragAndDrop(TransferMode.ANY);
        ClipboardContent content = new ClipboardContent();
        content.putImage(penSet.getImage());
        db.setContent(content);
        event.consume();
             }
    
    }

    @FXML        //7
    private void penDone(DragEvent event) {
        

            Dragboard db = event.getDragboard();

           if (db.hasImage()&& !flage7) {
                penGet.setImage(db.getImage());
                   numScore = Integer.valueOf(score.getText()) + 10;
               score.setText(String.valueOf(numScore));
               scoreForBoard=score.getText();
               flage7 = true;
            AudioClip  True= new AudioClip(this.getClass().getResource("true.m4a").toString());
            True.setVolume(0.15);
            True.play();
            if (numScore==100){
            Parent root;
                    try {
                        root = FXMLLoader.load(getClass().getResource("fix_win.fxml"));

                        Scene scene = new Scene(root);
                        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                        stage.setTitle("Congratulations !!!");
                        stage.setScene(scene);
                        stage.show();
                        PauseTransition wait1 = new PauseTransition(Duration.seconds(1));
                        wait1.setOnFinished(e -> {
                            AudioClip  win= new AudioClip(this.getClass().getResource("win.m4a").toString());
                            win.play();
                        });
                        wait1.play();
                        AudioClip  win2= new AudioClip(this.getClass().getResource("for_win.m4a").toString());
                        win2.setVolume(0.13);
                        win2.play();
                    } catch (IOException ex) {
                        Logger.getLogger(FixController.class.getName()).log(Level.SEVERE, null, ex);
                    }
                System.out.println("drag done ......lungs ");
            }
           }
           
             event.consume(); 

        }
    

    @FXML
    private void kidneysDetected(MouseEvent event) {
       
             if (minute==0 && second==0){
            Parent root;
              try {
                  root = FXMLLoader.load(getClass().getResource("fix_lose.fxml"));
                  Scene scene = new Scene(root);
            Stage stage=(Stage) ((Node)event.getSource()).getScene().getWindow();
            stage.setTitle("Oh Nooo !!!");
            stage.setScene(scene);
            stage.show();
            PauseTransition wait1 = new PauseTransition(Duration.seconds(1));
            wait1.setOnFinished(e -> {
                AudioClip  lose= new AudioClip(this.getClass().getResource("lose.m4a").toString());
                lose.play();
            });
            wait1.play();
            AudioClip  lose2= new AudioClip(this.getClass().getResource("for_lose.m4a").toString());
            lose2.setVolume(0.13);
            lose2.play();
              } catch (IOException ex) {
                  Logger.getLogger(FixController.class.getName()).log(Level.SEVERE, null, ex);
              }
            
        }
             else{
        Dragboard db = kidneysSet.startDragAndDrop(TransferMode.ANY);
        ClipboardContent content = new ClipboardContent();
        content.putImage(kidneysSet.getImage());
        db.setContent(content);
        event.consume();
             }
 
    }

    @FXML       //8
    private void kidneysDone(DragEvent event) {
        

            Dragboard db = event.getDragboard();

           if (db.hasImage()&& !flage8) {
                kidneysGett.setImage(db.getImage());
                   numScore = Integer.valueOf(score.getText()) + 10;
               score.setText(String.valueOf(numScore));
               scoreForBoard=score.getText();
               flage8 = true;
            AudioClip  True= new AudioClip(this.getClass().getResource("true.m4a").toString());
            True.setVolume(0.15);
            True.play();
            if (numScore==100){
            Parent root;
                    try {
                        root = FXMLLoader.load(getClass().getResource("fix_win.fxml"));

                        Scene scene = new Scene(root);
                        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                        stage.setTitle("Congratulations !!!");
                        stage.setScene(scene);
                        stage.show();
                        PauseTransition wait1 = new PauseTransition(Duration.seconds(1));
                        wait1.setOnFinished(e -> {
                            AudioClip  win= new AudioClip(this.getClass().getResource("win.m4a").toString());
                            win.play();
                        });
                        wait1.play();
                        AudioClip  win2= new AudioClip(this.getClass().getResource("for_win.m4a").toString());
                        win2.setVolume(0.13);
                        win2.play();
                    } catch (IOException ex) {
                        Logger.getLogger(FixController.class.getName()).log(Level.SEVERE, null, ex);
                    }
                System.out.println("drag done ......lungs ");
            }
           }
           
             event.consume(); 

        }
    
    @FXML
    private void smallDetected(MouseEvent event) {
       
             if (minute==0 && second==0){
            Parent root;
              try {
                  root = FXMLLoader.load(getClass().getResource("fix_lose.fxml"));
                  Scene scene = new Scene(root);
            Stage stage=(Stage) ((Node)event.getSource()).getScene().getWindow();
            stage.setTitle("Oh Nooo !!!");
            stage.setScene(scene);
            stage.show();
            PauseTransition wait1 = new PauseTransition(Duration.seconds(1));
            wait1.setOnFinished(e -> {
                AudioClip  lose= new AudioClip(this.getClass().getResource("lose.m4a").toString());
                lose.play();
            });
            wait1.play();
            AudioClip  lose2= new AudioClip(this.getClass().getResource("for_lose.m4a").toString());
            lose2.setVolume(0.13);
            lose2.play();
              } catch (IOException ex) {
                  Logger.getLogger(FixController.class.getName()).log(Level.SEVERE, null, ex);
              }
            
        }
             else{
        Dragboard db = smallintestineSet.startDragAndDrop(TransferMode.ANY);
        ClipboardContent content = new ClipboardContent();
        content.putImage(smallintestineSet.getImage());
        db.setContent(content);
        event.consume();
             }

    }

    @FXML       //9
    private void smallDone(DragEvent event) {
        
     

            Dragboard db = event.getDragboard();

           if (db.hasImage()&& !flage9) {
                smallintestiGet.setImage(db.getImage());
                   numScore = Integer.valueOf(score.getText()) + 10;
               score.setText(String.valueOf(numScore));
               scoreForBoard=score.getText();
               flage9 = true;
            AudioClip  True= new AudioClip(this.getClass().getResource("true.m4a").toString());
            True.setVolume(0.15);
            True.play();
            if (numScore==100){
            Parent root;
                    try {
                        root = FXMLLoader.load(getClass().getResource("fix_win.fxml"));

                        Scene scene = new Scene(root);
                        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                        stage.setTitle("Congratulations !!!");
                        stage.setScene(scene);
                        stage.show();
                        PauseTransition wait1 = new PauseTransition(Duration.seconds(1));
                        wait1.setOnFinished(e -> {
                            AudioClip  win= new AudioClip(this.getClass().getResource("win.m4a").toString());
                            win.play();
                        });
                        wait1.play();
                        AudioClip  win2= new AudioClip(this.getClass().getResource("for_win.m4a").toString());
                        win2.setVolume(0.13);
                        win2.play();
                    } catch (IOException ex) {
                        Logger.getLogger(FixController.class.getName()).log(Level.SEVERE, null, ex);
                    }
                System.out.println("drag done ......lungs ");
            }
           }
           
             event.consume(); 

        }
    

    @FXML
    private void espDetected(MouseEvent event) {
       
             if (minute==0 && second==0){
            Parent root;
              try {
                  root = FXMLLoader.load(getClass().getResource("fix_lose.fxml"));
                  Scene scene = new Scene(root);
            Stage stage=(Stage) ((Node)event.getSource()).getScene().getWindow();
            stage.setTitle("Oh Nooo !!!");
            stage.setScene(scene);
            stage.show();
            PauseTransition wait1 = new PauseTransition(Duration.seconds(1));
            wait1.setOnFinished(e -> {
                AudioClip  lose= new AudioClip(this.getClass().getResource("lose.m4a").toString());
                lose.play();
            });
            wait1.play();
            AudioClip  lose2= new AudioClip(this.getClass().getResource("for_lose.m4a").toString());
            lose2.setVolume(0.13);
            lose2.play();
              } catch (IOException ex) {
                  Logger.getLogger(FixController.class.getName()).log(Level.SEVERE, null, ex);
              }
            
        }
             else{
        Dragboard db = esophagusSet.startDragAndDrop(TransferMode.ANY);
        ClipboardContent content = new ClipboardContent();
        content.putImage(esophagusSet.getImage());
        db.setContent(content);
        event.consume();
             }
    
    }

    @FXML       //10
    private void espDone(DragEvent event) {
       
        

            Dragboard db = event.getDragboard();

           if (db.hasImage()&& !flage10) {
                esophagusGet.setImage(db.getImage());
                  numScore = Integer.valueOf(score.getText()) + 10;
               score.setText(String.valueOf(numScore));
               scoreForBoard=score.getText();
               flage10 = true;
            AudioClip  True= new AudioClip(this.getClass().getResource("true.m4a").toString());
            True.setVolume(0.15);
            True.play();
            if (numScore==100){
            Parent root;
                    try {
                        root = FXMLLoader.load(getClass().getResource("fix_win.fxml"));

                        Scene scene = new Scene(root);
                        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                        stage.setTitle("Congratulations !!!");
                        stage.setScene(scene);
                        stage.show();
                        PauseTransition wait1 = new PauseTransition(Duration.seconds(1));
                        wait1.setOnFinished(e -> {
                            AudioClip  win= new AudioClip(this.getClass().getResource("win.m4a").toString());
                            win.play();
                        });
                        wait1.play();
                        AudioClip  win2= new AudioClip(this.getClass().getResource("for_win.m4a").toString());
                        win2.setVolume(0.13);
                        win2.play();
                    } catch (IOException ex) {
                        Logger.getLogger(FixController.class.getName()).log(Level.SEVERE, null, ex);
                    }
               
            }
           }
           
             event.consume(); 

        }
}