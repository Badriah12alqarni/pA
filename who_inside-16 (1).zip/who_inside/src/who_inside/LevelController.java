/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package who_inside;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.media.AudioClip;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Moon
 */
public class LevelController implements Initializable {

    @FXML
    private Button signout;
    @FXML
    private Button btnDiscover;
    @FXML
    private Button btnFix;
    @FXML
    private Button btnRemember;
    @FXML
    private Button btnBoard;
    @FXML
    private Button btnabout;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void setSignout(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("home.fxml"));
        Scene scene = new Scene(root);
        Stage stage=(Stage) ((Node)event.getSource()).getScene().getWindow();
        stage.setTitle("Who's Inside ?");
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void setDiscover(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("discover.fxml"));
        Scene scene = new Scene(root);
        Stage stage=(Stage) ((Node)event.getSource()).getScene().getWindow();
        stage.setTitle("Let's Discover !");
        stage.setScene(scene);
        stage.show();
        AudioClip  discover= new AudioClip(this.getClass().getResource("let_discover.m4a").toString());
       discover.play();
    }

    @FXML
    private void setFix(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("fix.fxml"));
        Scene scene = new Scene(root);
        Stage stage=(Stage) ((Node)event.getSource()).getScene().getWindow();
        stage.setTitle("Let's Fix It Up !");
        stage.setScene(scene);
        stage.show();
        AudioClip  fix= new AudioClip(this.getClass().getResource("let_fix.m4a").toString());
       fix.play();
    }

    @FXML
    private void setRemember(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("remember.fxml"));
        Scene scene = new Scene(root);
        Stage stage=(Stage) ((Node)event.getSource()).getScene().getWindow();
        stage.setTitle("Let's Remember !");
        stage.setScene(scene);
        stage.show();
        AudioClip  remember= new AudioClip(this.getClass().getResource("let_remember.m4a").toString());
       remember.play();
    }

    @FXML
    private void setBoard(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("board.fxml"));
        Scene scene = new Scene(root);
        Stage stage=(Stage) ((Node)event.getSource()).getScene().getWindow();
        stage.setTitle("Champion's Board !!!");
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void setaboutus(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("about_us.fxml"));
        Scene scene = new Scene(root);
        Stage stage=(Stage) ((Node)event.getSource()).getScene().getWindow();
        stage.setTitle("About us!");
        stage.setScene(scene);
        stage.show();
    }
    
}
