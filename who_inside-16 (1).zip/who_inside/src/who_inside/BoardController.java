/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package who_inside;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.stage.Stage;
import javafx.scene.image.ImageView;
import javafx.animation.Animation;
import javafx.animation.Interpolator;
import javafx.animation.Transition;
import javafx.animation.ScaleTransition;
import javafx.animation.TranslateTransition;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.util.Duration;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import static who_inside.SignInController.us;
import static who_inside.FixController.scoreForBoard;
import static who_inside.RememberController.scoreForBoardRember;

/**
 * FXML Controller class
 *
 * @author Moon
 */
public class BoardController implements Initializable {

    @FXML
    private ListView userscore;
    @FXML
    private ListView username;
    @FXML
    private Label score;
    @FXML
    private Label user;
    @FXML
    private ComboBox<String> box;
    @FXML
    private Button btnPre;
    @FXML
    private ImageView star6;
    @FXML
    private ImageView star5;
    @FXML
    private ImageView star4;
    @FXML
    private ImageView star3;
    @FXML
    private ImageView star1;
    @FXML
    private ImageView star2;
    
    ObservableList<String> list = FXCollections.observableArrayList("هيا لنصلح الأمر","هيا لنتذكر");
    ObservableList<String>  obUserName=FXCollections.observableArrayList();
    ObservableList<String>  obUserScore=FXCollections.observableArrayList();
    
    @FXML
    private Label save;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
      //https://youtu.be/UdGiuDDi7Rg
        //scale star 5
       ScaleTransition scale =new ScaleTransition();
       scale.setNode(star5);
       scale.setDuration(Duration.millis(1000));
       scale.setCycleCount(TranslateTransition.INDEFINITE);
       scale.setInterpolator(Interpolator.LINEAR);
       scale.setByX(0.50);
       scale.setByY(0.50);
       scale.setAutoReverse(true);
       scale.play();
       //scale star 6
       ScaleTransition scale1 =new ScaleTransition();
       scale1.setNode(star6);
       scale1.setDuration(Duration.millis(1000));
       scale1.setCycleCount(TranslateTransition.INDEFINITE);
       scale1.setInterpolator(Interpolator.LINEAR);
       scale1.setByX(0.50);
       scale1.setByY(0.50);
       scale1.setAutoReverse(true);
       scale1.play();
       //scale star 4
       ScaleTransition scale5 =new ScaleTransition();
       scale5.setNode(star4);
       scale5.setDuration(Duration.millis(1000));
       scale5.setCycleCount(TranslateTransition.INDEFINITE);
       scale5.setInterpolator(Interpolator.LINEAR);
       scale5.setByX(0.50);
       scale5.setByY(0.50);
       scale5.setAutoReverse(true);
       scale5.play();  
        //scale star 3
       ScaleTransition scale6 =new ScaleTransition();
       scale6.setNode(star3);
       scale6.setDuration(Duration.millis(1000));
       scale6.setCycleCount(TranslateTransition.INDEFINITE);
       scale6.setInterpolator(Interpolator.LINEAR);
       scale6.setByX(0.50);
       scale6.setByY(0.50);
       scale6.setAutoReverse(true);
       scale6.play();
        //scale star 1
       ScaleTransition scale8 =new ScaleTransition();
       scale8.setNode(star1);
       scale8.setDuration(Duration.millis(1000));
       scale8.setCycleCount(TranslateTransition.INDEFINITE);
       scale8.setInterpolator(Interpolator.LINEAR);
       scale8.setByX(0.50);
       scale8.setByY(0.50);
       scale8.setAutoReverse(true);
       scale8.play(); 
        //scale star 2
       ScaleTransition scale13 =new ScaleTransition();
       scale13.setNode(star2);
       scale13.setDuration(Duration.millis(1000));
       scale13.setCycleCount(TranslateTransition.INDEFINITE);
       scale13.setInterpolator(Interpolator.LINEAR);
       scale13.setByX(0.50);
       scale13.setByY(0.50);
       scale13.setAutoReverse(true);
       scale13.play();
       
       board b=new board();
       
        username.setItems(obUserName);
        userscore.setItems(obUserScore);
       
        box.getItems().addAll(list);
        
        
        box.setOnAction(e->
        {
                obUserName.clear();
                obUserScore.clear();
                if (box.getValue() == "هيا لنصلح الأمر"){
                   Session sCh = HibernateUtil.getSessionFactory().openSession();
                   List<board> lList = null;
                   String qu = "from board";
                   Query q = sCh.createQuery(qu);
                   lList = q.list();
                   sCh.close();
                   boolean find = false;
                   for(board l: lList)
                   {
                      if(l.getUsername().equals(us) ){
                      find= true;
                      break;
                    }
            
                    }
                    if (find) {
                       Session sUp = HibernateUtil.getSessionFactory().openSession();
                        Transaction tx = sUp.beginTransaction();
                        
                        board Scoreupdate = null;
                        String username = us;
                        Scoreupdate = (board)sUp.get(board.class, username);
                        Scoreupdate.setScore(scoreForBoard);
                        sUp.update(Scoreupdate);

                        tx.commit();
                        sUp.close();
                        Session session = HibernateUtil.getSessionFactory().openSession();
                    List<board> sList = null;
                    String queryStr = "from board";
                    Query query = session.createQuery(queryStr);
                    sList = query.list();
                    session.close();

                    for (board s : sList) {
                        
                        obUserName.add(s.getUsername());
                        obUserScore.add(s.getScore());
                       

                    }
                        System.out.println("username " + username + " was updated by: " + Scoreupdate.getScore());
                    } else {

                        System.out.println(us);
                        System.out.println(scoreForBoard);
                        obUserName.add(us);
                        obUserScore.add(scoreForBoard);
                        b.setUsername(us);
                        b.setScore(scoreForBoard);
                        Session s = HibernateUtil.getSessionFactory().openSession();

                       Transaction tx = s.beginTransaction();
                       s.save(b);
                       tx.commit();
                       s.close();
                        System.out.println("store to database done");
                        Session session = HibernateUtil.getSessionFactory().openSession();
                    List<board> sList = null;
                    String queryStr = "from board";
                    Query query = session.createQuery(queryStr);
                    sList = query.list();
                    session.close();

                    for (board bor : sList) {
                        
                        obUserName.add(bor.getUsername());
                        obUserScore.add(bor.getScore());
                       

                    }
                    }
                }
                else if (box.getValue() == "هيا لنتذكر"){
                    Session sCh = HibernateUtil.getSessionFactory().openSession();
                   List<board> lList = null;
                   String qu = "from board";
                   Query q = sCh.createQuery(qu);
                   lList = q.list();
                   sCh.close();
                   boolean find = false;
                   for(board l: lList)
                   {
                      if(l.getUsername().equals(us) ){
                      find= true;
                      break;
                    }
            
                    }
                    if (find) {
                       Session sUp = HibernateUtil.getSessionFactory().openSession();
                        Transaction tx = sUp.beginTransaction();
                        
                        board Scoreupdate = null;
                        String username = us;
                        Scoreupdate = (board)sUp.get(board.class, username);
                        Scoreupdate.setScoreRem(scoreForBoardRember);
                        sUp.update(Scoreupdate);

                        tx.commit();
                        sUp.close();
                        Session session = HibernateUtil.getSessionFactory().openSession();
                    List<board> sList = null;
                    String queryStr = "from board";
                    Query query = session.createQuery(queryStr);
                    sList = query.list();
                    session.close();

                    for (board s : sList) {
                        
                        obUserName.add(s.getUsername());
                        obUserScore.add(s.getScoreRem());
                       

                    }
                        System.out.println("username " + username + " was updated by: " + Scoreupdate.getScore());
                    } else {

                        System.out.println(us);
                        System.out.println(scoreForBoardRember);
                        obUserName.add(us);
                        obUserScore.add(scoreForBoardRember);
                        b.setUsername(us);
                        b.setScoreRem(scoreForBoardRember);
                        Session s = HibernateUtil.getSessionFactory().openSession();

                       Transaction tx = s.beginTransaction();
                       s.save(b);
                       tx.commit();
                       s.close();
                        System.out.println("store to database done");
                        Session session = HibernateUtil.getSessionFactory().openSession();
                    List<board> sList = null;
                    String queryStr = "from board";
                    Query query = session.createQuery(queryStr);
                    sList = query.list();
                    session.close();

                    for (board bor : sList) {
                        
                        obUserName.add(bor.getUsername());
                        obUserScore.add(bor.getScoreRem());
                       

                    }
                    }
                  
                    
                }
                    
        });
       
       
           
                       
                       

               
        

    }    

    @FXML
    private void setPre(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("level.fxml"));
        Scene scene = new Scene(root);
        Stage stage=(Stage) ((Node)event.getSource()).getScene().getWindow();
        stage.setTitle("Levels");
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void save(KeyEvent event) {
        if (event.getCode() == KeyCode.CONTROL ){
          
            File  fileData= new File("BoardFile.txt");

            try (PrintWriter output = new PrintWriter(fileData)){
                {
                    for (String s : obUserName) {
                        String child = "Child Name: " + obUserName.get(obUserName.indexOf(s)) + ", " + "Score : " + obUserScore.get(obUserName.indexOf(s))  ;
                        output.println(child + "\n");
                    }
                    output.close(); 
                }
            } catch (IOException a) {
                System.out.println("exception");
            }
            System.out.println("file store done");
      }
    }
   
}
