/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package who_inside;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.animation.PauseTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.media.AudioClip;
import javafx.stage.Stage;
import javafx.util.Duration;

/**
 * FXML Controller class
 *
 * @author Moon
 */
public class DiscoverController implements Initializable {

    @FXML
    private Button btPrePage1;
    @FXML
    private Button brain;
    @FXML
    private Button Liver;
    @FXML
    private Button stomach;
    @FXML
    private Button kidneys;
    @FXML
    private Button heart;
    @FXML
    private Button lungs;
    @FXML
    private Button pancreas;
    @FXML
    private Button largeIntestine;
    @FXML
    private Button smallIntestine;
    @FXML
    private Button esophagus;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void btPrePage(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("level.fxml"));
        Scene scene = new Scene(root);
        Stage stage=(Stage) ((Node)event.getSource()).getScene().getWindow();
        stage.setTitle("Levels");
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void brainAction(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("brain.fxml"));
        Scene scene = new Scene(root);
        Stage stage=(Stage) ((Node)event.getSource()).getScene().getWindow();
        stage.setTitle("Brain");
        stage.setScene(scene);
        stage.show();
        
        PauseTransition wait1 = new PauseTransition(Duration.seconds(1));
       wait1.setOnFinished(e -> {
            AudioClip brain1 = new AudioClip(this.getClass().getResource("brain.m4a").toString());
            brain1.play();
        });
           wait1.play();
       PauseTransition wait2 = new PauseTransition(Duration.seconds(4));
       wait2.setOnFinished(e -> {
            AudioClip brain2 = new AudioClip(this.getClass().getResource("brain_me.m4a").toString());
            brain2.play();
        });
           wait2.play();
    }

    @FXML
    private void LiverAction(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("liver.fxml"));
        Scene scene = new Scene(root);
        Stage stage=(Stage) ((Node)event.getSource()).getScene().getWindow();
        stage.setTitle("Liver");
        stage.setScene(scene);
        stage.show();
        
        PauseTransition wait1 = new PauseTransition(Duration.seconds(1));
       wait1.setOnFinished(e -> {
            AudioClip brain1 = new AudioClip(this.getClass().getResource("liver.m4a").toString());
            brain1.play();
        });
           wait1.play();
       PauseTransition wait2 = new PauseTransition(Duration.seconds(6));
       wait2.setOnFinished(e -> {
            AudioClip brain2 = new AudioClip(this.getClass().getResource("liver_me.m4a").toString());
            brain2.play();
        });
           wait2.play();
    }

    @FXML
    private void stomachAction(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("stomach.fxml"));
        Scene scene = new Scene(root);
        Stage stage=(Stage) ((Node)event.getSource()).getScene().getWindow();
        stage.setTitle("Stomach");
        stage.setScene(scene);
        stage.show();
        
        PauseTransition wait1 = new PauseTransition(Duration.seconds(1));
       wait1.setOnFinished(e -> {
            AudioClip brain1 = new AudioClip(this.getClass().getResource("stomach.m4a").toString());
            brain1.play();
        });
           wait1.play();
       PauseTransition wait2 = new PauseTransition(Duration.seconds(7));
       wait2.setOnFinished(e -> {
            AudioClip brain2 = new AudioClip(this.getClass().getResource("stomach_me.m4a").toString());
            brain2.play();
        });
           wait2.play();
    }

    @FXML
    private void kidneysAction(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("kidneys.fxml"));
        Scene scene = new Scene(root);
        Stage stage=(Stage) ((Node)event.getSource()).getScene().getWindow();
        stage.setTitle("Kidneys");
        stage.setScene(scene);
        stage.show();
        
        PauseTransition wait1 = new PauseTransition(Duration.seconds(1));
       wait1.setOnFinished(e -> {
            AudioClip brain1 = new AudioClip(this.getClass().getResource("kidneys.m4a").toString());
            brain1.play();
        });
           wait1.play();
       PauseTransition wait2 = new PauseTransition(Duration.seconds(6));
       wait2.setOnFinished(e -> {
            AudioClip brain2 = new AudioClip(this.getClass().getResource("kidney_me.m4a").toString());
            brain2.play();
        });
           wait2.play();
    }

    @FXML
    private void heartAction(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("heart.fxml"));
        Scene scene = new Scene(root);
        Stage stage=(Stage) ((Node)event.getSource()).getScene().getWindow();
        stage.setTitle("Heart");
        stage.setScene(scene);
        stage.show();
        
        PauseTransition wait1 = new PauseTransition(Duration.seconds(1));
       wait1.setOnFinished(e -> {
            AudioClip brain1 = new AudioClip(this.getClass().getResource("heart.m4a").toString());
            brain1.play();
        });
           wait1.play();
       PauseTransition wait2 = new PauseTransition(Duration.seconds(6));
       wait2.setOnFinished(e -> {
            AudioClip brain2 = new AudioClip(this.getClass().getResource("heart_me.m4a").toString());
            brain2.play();
        });
           wait2.play();
    }

    @FXML
    private void lungsAction(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("lungs.fxml"));
        Scene scene = new Scene(root);
        Stage stage=(Stage) ((Node)event.getSource()).getScene().getWindow();
        stage.setTitle("Lungs");
        stage.setScene(scene);
        stage.show();
        
        PauseTransition wait1 = new PauseTransition(Duration.seconds(1));
       wait1.setOnFinished(e -> {
            AudioClip brain1 = new AudioClip(this.getClass().getResource("lungs.m4a").toString());
            brain1.play();
        });
           wait1.play();
       PauseTransition wait2 = new PauseTransition(Duration.seconds(6));
       wait2.setOnFinished(e -> {
            AudioClip brain2 = new AudioClip(this.getClass().getResource("lungs_me.m4a").toString());
            brain2.play();
        });
           wait2.play();
    }

    @FXML
    private void pancreasAction(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("pancreas.fxml"));
        Scene scene = new Scene(root);
        Stage stage=(Stage) ((Node)event.getSource()).getScene().getWindow();
        stage.setTitle("Pancreas");
        stage.setScene(scene);
        stage.show();
        
        PauseTransition wait1 = new PauseTransition(Duration.seconds(1));
       wait1.setOnFinished(e -> {
            AudioClip brain1 = new AudioClip(this.getClass().getResource("pancreas.m4a").toString());
            brain1.play();
        });
           wait1.play();
       PauseTransition wait2 = new PauseTransition(Duration.seconds(7));
       wait2.setOnFinished(e -> {
            AudioClip brain2 = new AudioClip(this.getClass().getResource("pancreas_me.m4a").toString());
            brain2.play();
        });
           wait2.play();
    }

    @FXML
    private void largeIntestineAction(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("largeIntestine.fxml"));
        Scene scene = new Scene(root);
        Stage stage=(Stage) ((Node)event.getSource()).getScene().getWindow();
        stage.setTitle("Large Intestine");
        stage.setScene(scene);
        stage.show();
        
        PauseTransition wait1 = new PauseTransition(Duration.seconds(1));
       wait1.setOnFinished(e -> {
            AudioClip brain1 = new AudioClip(this.getClass().getResource("large_intestine.m4a").toString());
            brain1.play();
        });
           wait1.play();
       PauseTransition wait2 = new PauseTransition(Duration.seconds(7));
       wait2.setOnFinished(e -> {
            AudioClip brain2 = new AudioClip(this.getClass().getResource("large_me.m4a").toString());
            brain2.play();
        });
           wait2.play();
    }

    @FXML
    private void smallIntestineAction(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("smallIntestine.fxml"));
        Scene scene = new Scene(root);
        Stage stage=(Stage) ((Node)event.getSource()).getScene().getWindow();
        stage.setTitle("Small Intestine");
        stage.setScene(scene);
        stage.show();
        
        PauseTransition wait1 = new PauseTransition(Duration.seconds(1));
       wait1.setOnFinished(e -> {
            AudioClip brain1 = new AudioClip(this.getClass().getResource("small_intestine.m4a").toString());
            brain1.play();
        });
           wait1.play();
       PauseTransition wait2 = new PauseTransition(Duration.seconds(7));
       wait2.setOnFinished(e -> {
            AudioClip brain2 = new AudioClip(this.getClass().getResource("small_me.m4a").toString());
            brain2.play();
        });
           wait2.play();
    }

    @FXML
    private void esophagusAction(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("esophagus.fxml"));
        Scene scene = new Scene(root);
        Stage stage=(Stage) ((Node)event.getSource()).getScene().getWindow();
        stage.setTitle("Esophagus");
        stage.setScene(scene);
        stage.show();
        
        PauseTransition wait1 = new PauseTransition(Duration.seconds(1));
       wait1.setOnFinished(e -> {
            AudioClip brain1 = new AudioClip(this.getClass().getResource("esophagus.m4a").toString());
            brain1.play();
        });
           wait1.play();
       PauseTransition wait2 = new PauseTransition(Duration.seconds(6));
       wait2.setOnFinished(e -> {
            AudioClip brain2 = new AudioClip(this.getClass().getResource("esophagus_me.m4a").toString());
            brain2.play();
        });
           wait2.play();
    }
    
}
