/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package who_inside;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.animation.PauseTransition;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;
import javafx.scene.media.AudioClip;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;

/**
 *
 * @author Moon
 */
public class Who_inside extends Application {
    
    @Override
    public void start(Stage primaryStage) throws Exception {
        //The idea and code of transition from -> https://gitgub.com/arwagh/Code-Wizard-Game
        Parent root = FXMLLoader.load(getClass().getResource("load.fxml"));      
        PauseTransition wait = new PauseTransition(Duration.seconds(5));
        Scene scene = new Scene(root); 
        primaryStage.setTitle("Who's Inside ?");
        primaryStage.getIcons().add(new Image(Who_inside.class.getResourceAsStream("icon.png")));
        primaryStage.setScene(scene);
        primaryStage.show();
        AudioClip  load= new AudioClip(this.getClass().getResource("start_load.m4a").toString());
        load.play();
        
        
        wait.setOnFinished(e -> {
            primaryStage.hide();
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("home.fxml"));
            AnchorPane rootStart = null;
            try {
                rootStart = loader.load();
            } catch (IOException ex) {
                Logger.getLogger(Who_inside.class.getName()).log(Level.SEVERE, null, ex);
            }
            Scene sceneStart = new Scene(rootStart);
            HomeController controller = loader.getController();
            primaryStage.setTitle("Who's Inside ?");
            primaryStage.setScene(sceneStart);
            primaryStage.show();
            AudioClip start = new AudioClip(this.getClass().getResource("start.m4a").toString());
            start.play();
        });
           wait.play();
        
    }
    public static void main(String[] args) {
        launch(args);
    }
    
}
