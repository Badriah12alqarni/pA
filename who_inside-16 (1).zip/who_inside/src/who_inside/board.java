/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package who_inside;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="board")
public class board implements java.io.Serializable{
    @Id 
    @Column(name="user")
    private String username;
    @Column(name="score")
    private String score;
    @Column(name="scoreRem")
    private String scoreRem;
    public board() {
    }

    public String getUsername() {
        return username;
    }

    public String getScore() {
        return score;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setScore(String score) {
        this.score = score;
    }

    public String getScoreRem() {
        return scoreRem;
    }

    public void setScoreRem(String scoreRem) {
        this.scoreRem = scoreRem;
    }
    
    
    
}
